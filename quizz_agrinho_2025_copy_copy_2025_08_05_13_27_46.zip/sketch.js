//intruções:clique na tela
//referências:chatgpt e google
//objetivo:aprender sobre a agricultura no paraná.
let etapa = 'capa'
let perguntaAtual = 0
let respostasCorretas = 0
let mostrarResposta = false

let textoInfo = `🌷🌸 O Paraná é um estado com agricultura forte e diversificada. Aqui se destacam a produção de soja, milho, trigo e feijão, além de frutas e verduras. A agricultura no Paraná contribui muito para a economia local e nacional, gerando empregos e alimentos de qualidade. 🌸🌷`

let perguntas = [
  {
    pergunta: "Qual é uma das principais culturas agrícolas do Paraná?",
    opcoes: ["Soja", "Arroz", "Café", "Cana-de-açúcar"],
    correta: 0
  },
  {
    pergunta: "Além de soja, que outra cultura é importante no Paraná?",
    opcoes: ["Milho", "Banana", "Cacau", "Uva"],
    correta: 0
  },
  {
    pergunta: "O que a agricultura do Paraná gera para a economia?",
    opcoes: ["Empregos e alimentos", "Só exportação", "Só tecnologia", "Só turismo"],
    correta: 0
  },
  {
    pergunta: "Qual dessas frutas é produzida no Paraná?",
    opcoes: ["Maçã", "Coco", "Abacaxi", "Limão"],
    correta: 0
  },
  {
    pergunta: "A agricultura no Paraná é:",
    opcoes: ["Diversificada", "Só soja", "Só milho", "Só trigo"],
    correta: 0
  }
]

function setup() {
  createCanvas(800, 600)
  textFont('Arial')
}

function draw() {
  if (etapa === 'capa') {
    mostrarCapa()
  } else {
    background(255, 192, 203)
    if (etapa === 'info') {
      mostrarInformacoes()
    } else if (etapa === 'quiz') {
      mostrarQuiz()
    } else if (etapa === 'fim') {
      mostrarFim()
    }
  }
}

function mostrarCapa() {
  background('#FADADD')
  fill('#800040')
  textSize(18)
  textAlign(CENTER, TOP)

  let instrucoes = [
    "🌸 Quiz sobre Agricultura no Paraná 🌸",
    "Olá! Vou te contar um pouco da agricultura e depois você irá responder um quiz de 5 perguntas.",
    "Instruções:",
    "1. Leia as informações com atenção.",
    "2. Responda as perguntas clicando na opção correta.",
    "3. Tente acertar o máximo de perguntas!",
    "Clique para começar!"
  ]

  let lineHeight = 24
  let totalHeight = instrucoes.length * lineHeight
  let yBase = (height - totalHeight) / 2

  for (let i = 0; i < instrucoes.length; i++) {
    text(instrucoes[i], width / 2, yBase + i * lineHeight)
  }
}

function mostrarInformacoes() {
  background('#FFC0CB')
  fill('#800040')
  textSize(20)
  textAlign(CENTER, CENTER)
  textWrap(WORD)

  let boxWidth = width - 150
  let boxX = width / 2
  let boxY = height / 2

  text(textoInfo, 100, boxY, boxWidth)

  fill('#C71585')
  textSize(18)
  text('Clique para continuar para o quiz', width / 2, height - 40)
}

function mostrarQuiz() {
  background('#FFB6C1')
  fill('#800040')
  textSize(18)
  textAlign(LEFT, TOP)
  text('Pergunta ' + (perguntaAtual + 1) + ' de 5:', 50, 50)

  textSize(16)
  text(perguntas[perguntaAtual].pergunta, 50, 80, width - 100)

  for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
    let y = 150 + i * 50
    let corBotao = '#FF69B4'
    if (mostrarResposta && i === perguntas[perguntaAtual].correta) {
      corBotao = '#FF1493'
    }
    noStroke()
    fill(corBotao)
    rect(50, y - 20, width - 100, 40, 10)

    fill(255)
    textAlign(LEFT, CENTER)
    text(perguntas[perguntaAtual].opcoes[i], 70, y)
  }

  if (mostrarResposta) {
    fill('#BD176A')
    textSize(16)
    textAlign(CENTER, TOP)
    let respostaTexto = "Resposta correta: " + perguntas[perguntaAtual].opcoes[perguntas[perguntaAtual].correta]
    text(respostaTexto, width / 2, height - 80)
  }
}

function mostrarFim() {
  background('#DF5EA4')
  fill(255)
  textAlign(CENTER, CENTER)
  textSize(32)
  text('Quiz finalizado! 🌷🎉', width / 2, height / 3)
  textSize(20)
  text('Você acertou ' + respostasCorretas + ' de 5 perguntas.', width / 2, height / 2)
  textSize(20)
  text('Clique para jogar novamente', width / 2, height / 2 + 50)
}

function mousePressed() {
  if (etapa === 'capa') {
    etapa = 'info'
  } else if (etapa === 'info') {
    etapa = 'quiz'
  } else if (etapa === 'quiz') {
    if (!mostrarResposta) {
      let yStart = 150
      let yEnd = yStart + perguntas[perguntaAtual].opcoes.length * 50
      if (mouseY > yStart - 20 && mouseY < yEnd) {
        let indexClicado = floor((mouseY - yStart + 20) / 50)
        if (indexClicado >= 0 && indexClicado < perguntas[perguntaAtual].opcoes.length) {
          if (indexClicado === perguntas[perguntaAtual].correta) {
            respostasCorretas++
          }
          mostrarResposta = true
          setTimeout(() => {
            perguntaAtual++
            mostrarResposta = false
            if (perguntaAtual >= perguntas.length) {
              etapa = 'fim'
            }
          }, 2000)
        }
      }
    }
  } else if (etapa === 'fim') {
    perguntaAtual = 0
    respostasCorretas = 0
    etapa = 'capa'
  }
}
